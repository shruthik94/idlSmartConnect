import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddmediaPage } from './addmedia';

@NgModule({
  declarations: [
    AddmediaPage,
  ],
  imports: [
    IonicPageModule.forChild(AddmediaPage),
  ],
})
export class AddmediaPageModule {}
